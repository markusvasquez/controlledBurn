
package vasudha.test;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import java.util.ArrayList;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.util.ArrayList;

import vasudha.test.Day;
import vasudha.test.R;

/**
 * Created by Vasudha on 6/4/2016.
 */

public class DayAdapter extends BaseAdapter {
    private LayoutInflater inflater;
    private ArrayList<Day> objects;

    private class ViewHolder {
        TextView caloriesEaten;
        TextView caloriesBurned;
        TextView weight;
        TextView date;
    }

    public DayAdapter(Context context, ArrayList<Day> objects) {
        inflater = LayoutInflater.from(context);
        this.objects = objects;
    }

    public int getCount() {
        return objects.size();
    }

    public Day getItem(int position) {
        return objects.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if(convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.listview_layout, null);
            holder.caloriesEaten = (TextView) convertView.findViewById(R.id.caloriesEaten);
            holder.caloriesBurned = (TextView) convertView.findViewById(R.id.caloriesBurned);
            holder.weight = (TextView) convertView.findViewById(R.id.weight);
            holder.date =(TextView)  convertView.findViewById(R.id.date);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.caloriesBurned.setText(String.valueOf(objects.get(position).getExercise()));
        holder.caloriesEaten.setText(String.valueOf(objects.get(position).getCalories()));
        holder.weight.setText(String.valueOf(objects.get(position).getScaleWeight()));
        DateTimeFormatter dtf = DateTimeFormat.forPattern("yyyy-MM-dd");
        DateTime jodatime = dtf.parseDateTime(objects.get(position).getDate().toString());
        DateTimeFormatter dtfOut = DateTimeFormat.forPattern("MM/dd/yyyy");
        holder.date.setText(dtfOut.print(jodatime));

        return convertView;
    }
}

