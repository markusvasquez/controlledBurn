package vasudha.test.Screens;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.mongodb.DB;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

import org.joda.time.LocalDate;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import vasudha.test.Day;
import vasudha.test.DayAdapter;
import vasudha.test.R;
import vasudha.test.Repository;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link diary.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link diary#newInstance} factory method to
 * create an instance of this fragment.
 */
public class diary extends Fragment {
    Repository repo;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public diary() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment diary.
     */
    // TODO: Rename and change types and number of parameters
    public static diary newInstance(String param1, String param2) {
        diary fragment = new diary();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView=inflater.inflate(R.layout.activity_diary,container,false);
        //new GetDataTask().execute("http://10.0.0.16:27017/test");

        repo = home.getRepo();
        LocalDate today = new LocalDate();
        ArrayList<Day> days = new ArrayList<>();
        Day dayToAdd = null;
        for(int i = 0; i < 30; i++){
            if(repo.caloriesRecorded(today)) {
                dayToAdd = repo.readDay(today);
                if (dayToAdd.caloriesRecorded() == true) {
                    days.add(dayToAdd);
                }
                today = today.minusDays(1);
            }
        }
        DayAdapter adapter = new DayAdapter(getActivity(),days);

        ListView listview = (ListView) rootView.findViewById(R.id.listView);
        listview.setAdapter(adapter);

        return rootView;
    }
/*
    class GetDataTask extends AsyncTask<String,Void,String> {

        List<DBObject> tokens;
        ProgressDialog progressDialog;


        private ArrayList<Day> dayify(List<DBObject> tokens){

            ArrayList<Day> result = new ArrayList<>();
            int j;
            DBObject current;
            Day dayToAdd;
            int caloriesEaten;
            int caloriesBurned;
            int weight;
            String date;
            for(j = 0; j < tokens.size(); j++ ){
                current = tokens.get(j);
                caloriesEaten = (Integer) current.get("caloriesEaten");
                caloriesBurned = (Integer) current.get("caloriesBurned");
                weight = (Integer) current.get("weight");
                date = (String) current.get("date");

                System.out.println("TEST " + caloriesEaten + " " + caloriesBurned + " " + weight);

                dayToAdd = new Day(caloriesEaten,caloriesBurned,weight,date);
                result.add(dayToAdd);
            }
            return result;
        }

        private void populateListView(List<DBObject> tokens){


            ArrayList<Day> list = dayify(tokens);
            DayAdapter adapter = new DayAdapter(getActivity(),list);

            ListView listview = (ListView) getView().findViewById(R.id.listView);
            listview.setAdapter(adapter);
           // progressDialog.dismiss();
        }


        @Override
        protected void onPreExecute(){
          //  progressDialog = new ProgressDialog(getActivity());
            //progressDialog.setMessage("Loading Data...");
          //  progressDialog.show();
        }

        @Override
        protected String doInBackground(String... params) {
            try{
                getData("lol");
                return "success";
            }
            catch (IOException e){
                return "Network error!";
            }
        }
        @Override
        protected void onPostExecute(String result){
            populateListView(tokens);

            if(progressDialog != null)
            {
                progressDialog.dismiss();
            }
        }
        private List<DBObject> getData(String urlPath) throws IOException{
            try{
                MongoClient mongoClient = new MongoClient("10.0.0.16",27017);
                DB db = mongoClient.getDB( "test" );
                System.out.println("CONNECTED");
                DBCursor cursor = db.getCollection("tblstatus").find();
                tokens = cursor.toArray();
                mongoClient.close();

            }catch (UnknownHostException e){
                System.out.println("Unknown Host Exception");
            }
            return tokens;
        }
    }
*/

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(String s) {
        if (mListener != null) {
            mListener.onDiaryInteraction();
        }
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try{
            mListener = (OnFragmentInteractionListener) context;
        }catch (ClassCastException e){
                throw new ClassCastException(context.toString());
        }
    }
    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onDiaryInteraction();
    }
}
