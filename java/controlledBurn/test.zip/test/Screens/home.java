package vasudha.test.Screens;


import android.app.Activity;
import android.app.Dialog;
import android.app.FragmentManager;
import android.content.Intent;
import android.graphics.Color;
import android.provider.MediaStore;
import android.app.Fragment;
import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.github.clans.fab.FloatingActionMenu;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.XAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.ViewPortHandler;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.RuntimeExecutionException;
import com.mongodb.DB;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.commons.lang.math.DoubleRange;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.json.JSONException;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import vasudha.test.PopUps.accountInfo;
import vasudha.test.PopUps.excerciseEntry;
import vasudha.test.PopUps.foodEntry;
import vasudha.test.PopUps.weightEntry;
import vasudha.test.R;
import vasudha.test.Repository;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link .} interface
 * to handle interaction events.
 * Use the {@link home#newInstance} factory method to
 * create an instance of this fragment.
 */
public class home extends Fragment implements accountInfo.OnDialogDismissListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    public static boolean firstTime = true;
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    LineChart chart;
    private FloatingActionMenu test;
    private static Repository repo = null;
    private LocalDate date;
    private int[] accountInformation;
    private PopupWindow popupWindow;
    private LayoutInflater layoutInflater;
    private RelativeLayout relativeLayout;
    private EditText caloriesEaten;
    private EditText caloriesBurned;
    private EditText weight;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private static View mainView;

    private account.OnFragmentInteractionListener mListener;

    public home() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment home.
     */
    // TODO: Rename and change types and number of parameters
    public static home newInstance(String param1, String param2) {
        home fragment = new home();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        final View cont = container;
        final View rootView = inflater.inflate(R.layout.activity_home, container, false);
        mainView = rootView;

        createRepository();

        MobileAds.initialize(getActivity(), "ca-app-pub-3940256099942544/6300978111");
        AdView mAdView = (AdView) rootView.findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice("96FEDA2D7ACF2C5C4C9BDF9DEE163971")
                .build();
        mAdView.loadAd(adRequest);




        //The FAB buttons
        com.github.clans.fab.FloatingActionButton weightButton = (com.github.clans.fab.FloatingActionButton) rootView.findViewById(R.id.menu_weight);
        weightButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                FragmentManager fm = getActivity().getFragmentManager();
                weightEntry newFragment = new weightEntry();
                newFragment.show(fm, "weight entry");

            }
        });

        com.github.clans.fab.FloatingActionButton exerciseButton = (com.github.clans.fab.FloatingActionButton) rootView.findViewById(R.id.menu_excercise);
        exerciseButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                excerciseEntry newFragment = new excerciseEntry();
                newFragment.show(getActivity().getFragmentManager(), "exercise button");

            }
        });

        com.github.clans.fab.FloatingActionButton foodButton = (com.github.clans.fab.FloatingActionButton) rootView.findViewById(R.id.menu_food);
        foodButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DialogFragment newFragment = new foodEntry();
                newFragment.show(getFragmentManager(), "food entry");
            }
        });

        test = (FloatingActionMenu) rootView.findViewById(R.id.menu);
        test.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
               /* layoutInflater = (LayoutInflater) getActivity().getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                ViewGroup container = (ViewGroup) layoutInflater.inflate(R.layout.popup_layout,relativeLayout);
                container.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);


                popupWindow = new PopupWindow(container,view.getMeasuredWidth(),view.getMeasuredHeight(),true);
                ((ViewGroup)container.getParent()).removeView(container);
                popupWindow.showAtLocation(relativeLayout,Gravity.NO_GRAVITY,100,100);

                Button submit = (Button)getView().findViewById(R.id.submitButton);
                submit.setOnClickListener(new View.OnClickListener(){
                    public void onClick(View view){
                        popupWindow.dismiss();

                        caloriesEaten = (EditText) getView().findViewById(R.id.caloriesEatenField);
                        caloriesBurned = (EditText)getView().findViewById(R.id.caloriesBurnedField);
                        weight = (EditText) getView().findViewById(R.id.weightField);
                        int caloriesEatenInput = Integer.parseInt(caloriesEaten.getText().toString());
                        int caloriesBurnedInput = Integer.parseInt(caloriesBurned.getText().toString());
                        int weightInput = Integer.parseInt(weight.getText().toString());

                        String url = "http://10.0.0.16:3000/api/status/";

                        Day d = new Day(url,caloriesEatenInput,caloriesBurnedInput,weightInput);
                        new PostDataTask().execute(d);
                        popupWindow.dismiss();
                    }
                });

            }
        });
        return rootView;*/

            }
        });

        //new UpdateGraph().execute("garbage");
        return rootView;
    }
    public void onDialogDismissListener(int[] account) {
        System.out.println("REACHED");
        URI path = (getActivity().getFilesDir()).toURI();
        LocalDate date = new LocalDate();

        boolean isMale;
        if(account[3] == 1){
            isMale = true;
        }
        else {
            isMale = false;
        }
        repo = new Repository(path,date,account[0],account[1],account[2],isMale);
        date = new LocalDate();
        TextView caloriesEaten = (TextView) mainView.findViewById(R.id.caloriesEaten);
        TextView exerciseCalories = (TextView) mainView.findViewById(R.id.exerciseCalories);
        TextView calorieGoals = (TextView) mainView.findViewById(R.id.totalGoals);
        TextView remainingCalories = (TextView) mainView.findViewById(R.id.caloriesRemaining);

        caloriesEaten.setText(Double.toString(repo.getCalories(date)));

        exerciseCalories.setText(Double.toString(repo.getExercise(date)));

        calorieGoals.setText(Double.toString(repo.getNEEE(date)));

        remainingCalories.setText(Double.toString(repo.getNEEE(date) - repo.getCalories(date) + repo.getExercise(date)));

    }
    public static void setCard(){
        LocalDate date = new LocalDate();

        TextView caloriesEaten = (TextView) mainView.findViewById(R.id.caloriesEaten);
        TextView exerciseCalories = (TextView) mainView.findViewById(R.id.exerciseCalories);
        TextView calorieGoals = (TextView) mainView.findViewById(R.id.totalGoals);
        TextView remainingCalories = (TextView) mainView.findViewById(R.id.caloriesRemaining);

        caloriesEaten.setText(Double.toString(repo.getCalories(date)));

        exerciseCalories.setText(Double.toString(repo.getExercise(date)));

        calorieGoals.setText(Double.toString(repo.getNEEE(date)));

        remainingCalories.setText(Double.toString(repo.getNEEE(date) - repo.getCalories(date) + repo.getExercise(date)));
    }




    /**
     * Checks to see if a repository is already initialized. If it is not, it creates and initializes a repository,
     * if it is initialized, then it creates an instance of repository that can be used for the session.
     * @return the repository that will be used for the session.
     */
    private void createRepository() {
        URI path = (getActivity().getFilesDir()).toURI();
        boolean initialized = Repository.repositoryInitialized(path);
        System.out.println("TESTPATH: " + path.toString());
        System.out.print(initialized);
        if (initialized == true) {
            System.out.println("INITIALIZED REPO");
            repo = new Repository(path);
            date = new LocalDate();
            TextView caloriesEaten = (TextView) mainView.findViewById(R.id.caloriesEaten);
            TextView exerciseCalories = (TextView) mainView.findViewById(R.id.exerciseCalories);
            TextView calorieGoals = (TextView) mainView.findViewById(R.id.totalGoals);
            TextView remainingCalories = (TextView) mainView.findViewById(R.id.caloriesRemaining);

            caloriesEaten.setText(Double.toString(repo.getCalories(date)));

            exerciseCalories.setText(Double.toString(repo.getExercise(date)));

            calorieGoals.setText(Double.toString(repo.getNEEE(date)));

            remainingCalories.setText(Double.toString(repo.getNEEE(date) - repo.getCalories(date) + repo.getExercise(date)));
            new UpdateGraph().execute("on create");

        } else {
            System.out.println("NEW REPO");
            accountInfo newFragment = new accountInfo();
            newFragment.setTargetFragment(this,0);
            newFragment.show(getActivity().getFragmentManager(), "accountInfo");
        }
    }
    public void setRepo(Repository repository){
        repo = repository;
    }
    public static Repository getRepo(){
        return repo;
    }








    public static class UpdateGraph extends AsyncTask<String,Void, String> {

        LineChart chart;
        ProgressDialog progressDialog;
        LineData trueWeight = null;
        LineData weight = null;
        LineData data = null;



        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                return updateGraph();

            } catch (IOException ex) {
                return "Network error !";
            } catch (JSONException ex) {
                return "Data Invalid !";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            chart = (LineChart) mainView.findViewById(R.id.chart);

            chart.setData(data);

            //chart.animateXY(2000, 2000);
            chart.setDrawGridBackground(false);
            chart.setDrawBorders(true);
            chart.setBorderWidth(1);
            chart.setPinchZoom(true);
            chart.notifyDataSetChanged();
            chart.invalidate();

            if (progressDialog != null) {
                progressDialog.dismiss();
            }
        }

        private String updateGraph() throws IOException, JSONException {
            ArrayList<Entry> trueEntries = new ArrayList<>();
            ArrayList<Entry> weightEntries = new ArrayList<>();
            ArrayList<String> xAxis = new ArrayList<>();
           /* File lastRecorded = new File("lastDate");
            Scanner s = new Scanner(lastRecorded);
            String date = s.next();
            String year = StringUtils.substringBefore("-",date);
            String month = StringUtils.substringBetween("-",date);
            String day = StringUtils.substringAfterLast("-",date);

            LocalDate tempDate = new LocalDate(Integer.parseInt(year),Integer.parseInt(month),Integer.parseInt(day));
            System.out.println("TEMPDATE EXISTS: " + repo.dayExists(tempDate));*/
            LocalDate tempDate = new LocalDate();
            tempDate = tempDate.minusDays(1);
            int i = 0;
            while(i < 7){
                if(repo.dayExists(tempDate)){
                    trueEntries.add(new Entry((float)repo.getWeightEst(tempDate),i));
                    DateTimeFormatter dtf = DateTimeFormat.forPattern("yyyy-MM-dd");
                    DateTime jodatime = dtf.parseDateTime(tempDate.toString());
                    DateTimeFormatter dtfOut = DateTimeFormat.forPattern("MM/dd");
                    xAxis.add(dtfOut.print(jodatime));
                    weightEntries.add(new Entry((float)repo.getScaleWeight(tempDate),i));
                    tempDate = tempDate.minusDays(1);
                    i++;
                }
            }
                //Collections.reverse(entries);
                Collections.reverse(xAxis);
                LineDataSet trueDataSet = new LineDataSet(trueEntries, "True Weight");
                LineDataSet scaleDataSet = new LineDataSet(weightEntries, "Scale Weight");
                trueDataSet.setColor(Color.rgb(0, 155, 0));
                scaleDataSet.setColor(Color.rgb(255,165,0));
                data = new LineData();
                //  data.addDataSet(trueDataSet);
                data.addDataSet(scaleDataSet);
                data.setXVals(xAxis);

           /* try{
                MongoClient mongoClient = new MongoClient("10.0.0.16",27017);
                DB db = mongoClient.getDB( "test" );
                System.out.println("CONNECTED");
                DBCursor cursor = db.getCollection("tblstatus").find();
                List<DBObject> tokens = cursor.toArray();
                int weight;
                String date;
                ArrayList<Entry> entries = new ArrayList<>();
                ArrayList<String> xAxis = new ArrayList<>();

                for(int i = 0; i < tokens.size(); i++){
                    DBObject current = tokens.get(i);
                    weight = (Integer)current.get("weight");
                    date = (String)current.get("date");
                    StringUtils.substringBeforeLast(date,"/");

                    entries.add(new Entry(weight, i));
                    xAxis.add(date);
                }
                LineDataSet dataset = new LineDataSet(entries, "Weight in lbs");
                dataset.setColor(Color.rgb(0, 155, 0));
                data = new LineData(xAxis,dataset);

            }catch (UnknownHostException e){
                System.out.print("UNKNOWN HOST");
            }*/
            return "success";
        }

    }

    /*class PostDataTask extends AsyncTask<Day, Void, String> {

        ProgressDialog progressDialog;
        LineData data = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Day... params) {

            try {
                return postData();

            } catch (IOException ex) {
                return "Network error !";
            } catch (JSONException ex) {
                return "Data Invalid !";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            chart = (LineChart) getActivity().findViewById(R.id.chart);

            chart.setData(data);
            chart.setDescription("True Weight");
            chart.animateXY(2000, 2000);
            chart.setDrawGridBackground(false);
            chart.setDrawBorders(true);
            chart.setPinchZoom(true);
            chart.notifyDataSetChanged();
            chart.invalidate();
            //mResult.setText(result);

            if (progressDialog != null) {
                progressDialog.dismiss();
            }
        }

        private String postData() throws IOException, JSONException {

            try {
                MongoClient mongoClient = new MongoClient("10.0.0.16", 27017);
                DB db = mongoClient.getDB("test");
                System.out.println("CONNECTED");
                DBCursor cursor = db.getCollection("tblstatus").find();
                List<DBObject> tokens = cursor.toArray();
                int weight;
                String date;
                ArrayList<Entry> entries = new ArrayList<>();
                ArrayList<String> xAxis = new ArrayList<>();

                for (int i = 0; i < tokens.size(); i++) {
                    DBObject current = tokens.get(i);
                    weight = (Integer) current.get("weight");
                    date = (String) current.get("date");
                    StringUtils.substringBeforeLast(date, "/");

                    entries.add(new Entry(weight, i));
                    xAxis.add(date);
                }
                LineDataSet dataset = new LineDataSet(entries, "Weight in lbs");
                dataset.setColor(Color.rgb(0, 155, 0));
                data = new LineData(xAxis, dataset);

            } catch (UnknownHostException e) {
                System.out.print("UNKNOWN HOST");
            }


            return "success";
        }
    }*/
}

