package vasudha.test;


import org.joda.time.LocalDate;

import java.io.Serializable;
import Jama.*;
import java.lang.*;

public class Day implements Serializable{

   //Set parameter values

   final static double[][] F_VALS = {{1, -1.0/3500},{0,1}};
   final static Matrix F = new Matrix(F_VALS);
   final static double[][] B_VALS = {{1.0/3500, -1.0/3500},{0,0}};
   final static Matrix B = new Matrix(B_VALS);
   final static double[][] Q_VALS = {{(1.0/17.5)*(1.0/17.5),0},{0,12*12}};
   final static Matrix Q = new Matrix(Q_VALS);
   final static double[][] Q_NO_TRACKING_VALS = {{(1.0/7)*(1.0/7),0},{0,12*12}};
   final static Matrix Q_NO_TRACKING = new Matrix(Q_NO_TRACKING_VALS);
   final static double[][] R_VALS = {{1.3*1.3}};
   final static Matrix R = new Matrix(R_VALS);
   final static double[][] H_VALS = {{1,0}};
   final static Matrix H = new Matrix(H_VALS);
   final static double[][] I_VALS = {{1,0},{0,1}};
   final static Matrix I = new Matrix(I_VALS);


   //set first day variance covariance values
  
   final static double[][] INITIAL_P_VALS = {{2*2,0},{0,200*200}};


   //Set values used in calculation of first day NEEE
   final static double NEEE_MASS_MULTIPLIER = 4.53138408;
   final static double NEEE_HEIGHT_MULTIPLIER = 15.875;
   final static double NEEE_AGE_MULTIPLIER = -4.92;
   final static double NEEE_FROM_MALE = 5.0;
   final static double NEEE_FROM_FEMALE = -161.0;
   final static double DEFAULT_NEEE_ACTIVITY_LEVEL = 1.5;


   //Declare class variables.

   private LocalDate date;

   private Matrix priorX;   //prior mean of state.
                            //State is [weight, neee]
   private Matrix priorP;   //prior variance-covariance of morning state
   private Matrix postX;    //Posteriors of the above
   private Matrix postP;
   private Matrix u;        //The controls. u = [calories, exercise].
   private Matrix z;        // The observation. z = [scaleWeight]
   
   private boolean calsRecorded; //Says whether or not the number of calories was recorded.
   private boolean zRecorded; //Says whether or not scale weight was recorded.

   //The main constructor that takes the previous day as its only argument.

   public Day(Day prevDay){

      //Set the new date.
   
      LocalDate prevDate = prevDay.getDate();
      date = prevDate.plusDays(1);
   
      //Indicate that nothing has been recorded yet.
      calsRecorded = false;
      zRecorded = false;

      //Get previous postX and postP.

      Matrix prevPostX = prevDay.getPostX();
      Matrix prevPostP = prevDay.getPostP();
      Matrix prevU = prevDay.getU();

      //Set priorX and priorP
 
      priorX = computePriorX(prevPostX, prevU);
      priorP = computePriorP(prevPostP);
   
      //Set default value of u.
      double[][] uVals = {{prevDay.getNEEE()},{0}};
      u = new Matrix(uVals);

      //instantiate the z as matrix of 0s
      double[][] zVals = {{0}};
      z = new Matrix(zVals);

      //Now that we've set the priors, we can update the posteriors. 
      //This will automatically update everything after it.

      updatePosteriors();   

   }

   //The constructor for the first day.
   //Weight is in pounds.
   //Height is in inches.
   //Age is in years.
   
   public Day(LocalDate newDate, double weight, double height, int age, boolean isMale){

      date = newDate;


      //Indicate that nothing has been recorded yet.
      calsRecorded = false;
      zRecorded = false;

      //Compute the "stupid" estimate of the user's neee using cross sectional formula.

      double neeeEstimate = computeNEEE(weight, height, age, isMale);

      //We'll act as if their initial weight recording was taken on the morning of the first day. 
      //The initial variance should be high enough that it doesn't matter.
   
      double[][] priorXVals = {{weight},{neeeEstimate}};
      priorX = new Matrix(priorXVals);
      priorP = new Matrix(INITIAL_P_VALS);

      //Set default value of u.
      double[][] uVals = {{neeeEstimate},{0}};
      u = new Matrix(uVals);


      //Record weight as z
      double[][] zVals = {{weight}};
      z = new Matrix(zVals);
      zRecorded = true;

      //Compute posteriors
      updatePosteriors();

   }

   //Method to multiply two matrices

   private Matrix times(Matrix A, Matrix B){
     
      Matrix ATimesB = A.times(B);
      return ATimesB;
   }

   
   //Method to add two matrices
   private Matrix plus(Matrix A, Matrix B){

      Matrix APlusB = A.plus(B);
      return APlusB;
   }

   //Method to subtract one matrix from another (A,B) -> A-B
   private Matrix minus(Matrix A, Matrix B){
      return A.minus(B);
   }

   //Method to compute priorX from previous posterior X
   private Matrix computePriorX(Matrix prevPostX, Matrix prevU){

      Matrix newPriorX = plus(times(F,prevPostX),times(B,prevU)); 
      return newPriorX;
   }

   //Method to compute priorP from previous posterior P

   private Matrix computePriorP(Matrix prevPostP){

      Matrix newPriorP= plus(times(F,times(prevPostP,F.transpose())),Q);

      //Make sure that P hasn't gotten too big.
      if(newPriorP.get(0,0) > INITIAL_P_VALS[0][0] || newPriorP.get(1,1) > INITIAL_P_VALS[1][1]){
      newPriorP = new Matrix(INITIAL_P_VALS);
      }
 
      return newPriorP;
   }

 
   //Method that returns today's estimate of neee. Should pull from morning posterior.
   public double getNEEE(){ 
      return postX.get(1,0);

   }


   //Method for setting scale weight.

   public void setScaleWeight(double weight){

      z.set(0,0,weight);
      zRecorded = true;

      //Update posterior
      updatePosteriors();
 
   }


   //This method computes posteriors.

   public void updatePosteriors(){

      //If the scale weight has been recorded, then do the full update
      //Otherwise, just copy the priors to the posteriors.   
      if(zRecorded){
         //Compute innovation
         Matrix y = minus(z, times(H,priorX));

         //Compute innovation covariance
         Matrix S = plus(times(H, times(priorP,H.transpose())),R);

         //Compute optimal Kalman gain
         Matrix K = times(priorP,times(H.transpose(),S.inverse()));

         //compute state posterior
         postX = plus(priorX,times(K,y));

         //compute covariance posterior
         postP = times(minus(I,times(K,H)),priorP);
      }
      else{
         postX = priorX.copy();
         postP = priorP.copy();
      }

   }


   //Computes an estimate of NEEE given weight, height, activity level, age and gender.
   // weight in lbs, height in inches, activity level from 
   private double computeNEEE(double weight, double height, int age, boolean isMale){

         double neee = 0;

         //contribution from mass.
         neee = neee + NEEE_MASS_MULTIPLIER*weight;
     
         //contribution from height
         neee = neee + NEEE_HEIGHT_MULTIPLIER*height;
       
         //contribution from age
         neee = neee + NEEE_AGE_MULTIPLIER*age;
  
         //contribution from gender
 
         if(isMale){
            neee = neee + NEEE_FROM_MALE;
         }
         else{
            neee = neee + NEEE_FROM_FEMALE;
         }

         //Switch from Basal to ``NEEE"
         neee = neee * DEFAULT_NEEE_ACTIVITY_LEVEL;
  
         return neee;

         
      }



   public double getScaleWeight(){
      if(zRecorded){
         return z.get(0,0);
      }
      else{
         throw new IllegalStateException("Scale weight not set!");
      }
   }


   public double getCalories(){
   
      if(calsRecorded){
         return u.get(0,0);
      }
      else{
         throw new IllegalStateException("Calories not set!");
      }
   }

   public double getExercise(){
    
      return u.get(1,0);
   }

   
   public void setCalories(double cals){

      u.set(0,0,cals);
      calsRecorded = true;
     
   }

   public void setExercise(double exercise){
  
      u.set(1,0,exercise);
      
   }

   
   
   public double getWeightEst(){

      return postX.get(0,0);
   }


   public LocalDate getDate(){
      return date;
   }


   public double getWeightEstSD(){

     return Math.sqrt(postP.get(0,0));
   }

   public double getNEEESD(){
      return Math.sqrt(postP.get(1,1));
   }


   private Matrix getPostX(){
      return postX;
   }

   private Matrix getPostP(){
      return postP;
   }


   private Matrix getU(){
      return u;
   }


   public boolean caloriesRecorded(){
      return calsRecorded;
   }


   public boolean scaleWeightRecorded(){
      return zRecorded;
   }

   public void setCaloriesRecorded(boolean wasRecorded){
      calsRecorded = wasRecorded;
   }

   public void setScaleWeightRecorded(boolean wasRecorded){
      zRecorded = wasRecorded;
   }
}




 
