package vasudha.test.PopUps;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.app.DialogFragment;


import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Vasudha on 6/16/2016.
 */
public class datedialog extends DialogFragment implements DatePickerDialog.OnDateSetListener{
    EditText txtDate;
    public datedialog(View view){
        txtDate = (EditText)view;
    }

    public Dialog onCreateDialog(Bundle savedInstanceState){
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        return  new DatePickerDialog(getActivity(), this, year, month, day);

    }
    public void onDateSet(DatePicker view, int year, int month, int day){
        final Calendar c =  Calendar.getInstance();
        c.set(year,month,day);
        Date d = c.getTime();
        String s = DateFormat.getDateInstance().format(d);
        txtDate.setText(s);
    }


}
