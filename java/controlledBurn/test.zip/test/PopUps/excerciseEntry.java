package vasudha.test.PopUps;

import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Color;
import android.app.DialogFragment;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;

import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

import org.apache.commons.lang.StringUtils;
import org.joda.time.LocalDate;
import org.json.JSONException;

import java.io.IOException;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import vasudha.test.R;
import vasudha.test.Repository;
import vasudha.test.Screens.home;

public class excerciseEntry extends DialogFragment {
    private EditText excerciseDate;
    private Repository repo;
    private View mainView;


    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        final View exerciseDialog = inflater.inflate(R.layout.excercise_layout_popup, null);
        mainView = exerciseDialog;

        excerciseDate = (EditText) exerciseDialog.findViewById(R.id.excerciseDate);
        final Calendar cal =  Calendar.getInstance();
        Date d = cal.getTime();
        String s = DateFormat.getDateInstance().format(d);
        excerciseDate.setText(s);
        excerciseDate.setInputType(InputType.TYPE_NULL);
        excerciseDate.requestFocus();
        excerciseDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                datedialog dialog = new datedialog(v);
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                dialog.show(ft, "datepicker");
            }
        });

        builder.setView(exerciseDialog);
        builder.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {


                EditText date = (EditText) getDialog().findViewById(R.id.excerciseDate);
                EditText caloriesBurnedField = (EditText) getDialog().findViewById(R.id.caloriesBurnedField);
                if(!caloriesBurnedField.getText().toString().equals("")) {
                    int caloriesBurned = Integer.parseInt(caloriesBurnedField.getText().toString());
                    String weightDate = date.getText().toString();
                    int month = parseMonth(StringUtils.substringBefore(weightDate, " "));
                    int day = Integer.parseInt(StringUtils.substringBetween(weightDate, " ", ","));
                    int year = Integer.parseInt((StringUtils.substringAfterLast(weightDate, ",").trim()));
                    LocalDate entryDate = new LocalDate(year, month, day);
                    repo = home.getRepo();
                    repo.setExercise(entryDate, (double) caloriesBurned);
                    home.setCard();
                    new home.UpdateGraph().execute("test");

                }
                // DBObject myDoc = collection.findOne();
                //System.out.println(myDoc);
                //System.out.println(collection.getCount());

                /*BasicDBObject searchQuery = new BasicDBObject();
                searchQuery.put("weight", 100);

                MongoCursor<Document> cursor = collection.find(searchQuery).iterator();
                try {
                    while (cursor.hasNext()) {
                        System.out.println(cursor.next().toJson());
                    }
                } finally {
                    cursor.close();
                }*/
            }
        });

        return builder.create();
    }
    public int parseMonth(String monthString) {

        switch (monthString) {
            case "Jan":
                return 1;
            case "Feb":
                return 2;
            case "Mar":
                return 3;
            case "Apr":
                return 4;
            case "May":
                return 5;
            case "Jun":
                return 6;
            case "Jul":
                return 7;
            case "Aug":
                return 8;
            case "Sep":
                return 9;
            case "Oct":
                return 10;
            case "Nov":
                return 11;
            case "Dec":
                return 12;
        }
        return 0;
    }
/*
    class PostDataTask extends AsyncTask<Day, Void, String> {

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = new ProgressDialog(getActivity());
            progressDialog.setMessage("Inserting data...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Day... params) {

            try {
                return postData(params[0].getDate(), params[0].getCaloriesBurned());
            } catch (IOException ex) {
                return "Network error !";
            } catch (JSONException ex) {
                return "Data Invalid !";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);


            if (progressDialog != null) {
                progressDialog.dismiss();
            }
        }

*/
/*
        private String postData(String date, int caloriesBurned) throws IOException, JSONException {
            try{
                MongoClient mongoClient = new MongoClient("10.0.0.16",27017);
                DB db = mongoClient.getDB( "test" );
                DBCollection coll = db.getCollection("tblstatus");
                BasicDBObject query = new BasicDBObject("date",date);
                DBCursor cursor = coll.find(query);
                if(cursor.hasNext()){
                    DBObject update = new BasicDBObject();
                    update.put("$set", new BasicDBObject("caloriesBurned", caloriesBurned));
                    db.getCollection("tblstatus").findAndModify(query, update);
                }
                else{
                    BasicDBObject doc = new BasicDBObject("caloriesEaten", 0)
                            .append("caloriesBurned", caloriesBurned )
                            .append("weight", 0)
                            .append("date", date);
                    coll.insert(doc);
                }
            }catch (UnknownHostException e){
                System.out.println("CUCK");
            }
            return "LOL";
        }
*//*

    }
*/


    }
