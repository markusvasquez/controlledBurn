package vasudha.test.PopUps;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.mongodb.BasicDBObject;
        import com.mongodb.DB;
        import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

import java.net.UnknownHostException;



import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Color;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;

import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import org.apache.commons.lang.StringUtils;
import org.joda.time.LocalDate;
import org.json.JSONException;

import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import vasudha.test.R;
import vasudha.test.Repository;
import vasudha.test.Screens.home;

public class weightEntry extends DialogFragment {

    private EditText weightDate;
    private Repository repo;


    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {


        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        final View weightDialog = inflater.inflate(R.layout.weight_popup_layout, null);

        weightDate = (EditText) weightDialog.findViewById(R.id.weightDate);
        final Calendar c = Calendar.getInstance();
        Date d = c.getTime();
        String s = DateFormat.getDateInstance().format(d);
        weightDate.setText(s);
        weightDate.setInputType(InputType.TYPE_NULL);
        weightDate.requestFocus();
        weightDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                datedialog dialog = new datedialog(v);
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                dialog.show(ft, "datepicker");
            }
        });

        builder.setView(weightDialog);
        builder.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {



                EditText date = (EditText) getDialog().findViewById(R.id.weightDate);
                EditText weightField = (EditText) getDialog().findViewById(R.id.weightField);
                if (!weightField.getText().toString().equals("")) {
                    int weight = Integer.parseInt(weightField.getText().toString());
                    String weightDate = date.getText().toString();
                    int month = parseMonth(StringUtils.substringBefore(weightDate, " "));
                    int day = Integer.parseInt(StringUtils.substringBetween(weightDate, " ", ","));
                    int year = Integer.parseInt((StringUtils.substringAfterLast(weightDate, ",").trim()));
                    LocalDate entryDate = new LocalDate(year, month, day);
                    repo = home.getRepo();
                    repo.setScaleWeight(entryDate, (double) weight);
                    new home.UpdateGraph().execute("test");

                }


                // DBObject myDoc = collection.findOne();
                //System.out.println(myDoc);
                //System.out.println(collection.getCount());

                /*BasicDBObject searchQuery = new BasicDBObject();
                searchQuery.put("weight", 100);

                MongoCursor<Document> cursor = collection.find(searchQuery).iterator();
                try {
                    while (cursor.hasNext()) {
                        System.out.println(cursor.next().toJson());
                    }
                } finally {
                    cursor.close();
                }*/
            }
        });

        return builder.create();
    }

    public int parseMonth(String monthString) {

        switch (monthString) {
            case "Jan":
                return 1;
            case "Feb":
                return 2;
            case "Mar":
                return 3;
            case "Apr":
                return 4;
            case "May":
                return 5;
            case "Jun":
                return 6;
            case "Jul":
                return 7;
            case "Aug":
                return 8;
            case "Sep":
                return 9;
            case "Oct":
                return 10;
            case "Nov":
                return 11;
            case "Dec":
                return 12;
        }
        return 0;
    }

    /*class PostDataTask extends AsyncTask<Day, Void, String> {

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = new ProgressDialog(getActivity());
            progressDialog.setMessage("Inserting data...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Day... params) {

            try {
                return postData(params[0].getDate(), params[0].getWeight());
            } catch (IOException ex) {
                return "Network error !";
            } catch (JSONException ex) {
                return "Data Invalid !";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            if (progressDialog != null) {
                progressDialog.dismiss();
            }
        }

        private String postData(String date, int weight) throws IOException, JSONException {
            try{
                MongoClient mongoClient = new MongoClient("10.0.0.16",27017);
                DB db = mongoClient.getDB( "test" );
                DBCollection coll = db.getCollection("tblstatus");
                BasicDBObject query = new BasicDBObject("date",date);
                DBCursor cursor = coll.find(query);
               if(cursor.hasNext()){
                   DBObject update = new BasicDBObject();
                   update.put("$set", new BasicDBObject("weight", weight));
                   db.getCollection("tblstatus").findAndModify(query, update);
               }
               else{
                   BasicDBObject doc = new BasicDBObject("caloriesEaten", 0)
                           .append("caloriesBurned", 0)
                           .append("weight", weight)
                           .append("date", date);
                   coll.insert(doc);
               }
            }catch (UnknownHostException e){
                System.out.println("CUCK");
            }
            return "LOL";
        }
    }
    class UpdateGraph extends AsyncTask<Day, Void, String> {

        LineChart chart;
        ProgressDialog progressDialog;
        LineData data = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Day... params) {

            try {
                return updateGraph();

            } catch (IOException ex) {
                return "Network error !";
            } catch (JSONException ex) {
                return "Data Invalid !";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            chart = (LineChart) getActivity().findViewById(R.id.chart);

            chart.setData(data);
            chart.setDescription("True Weight");
            //chart.animateXY(2000, 2000);
            chart.setDrawGridBackground(false);
            chart.setDrawBorders(true);
            chart.setBorderWidth(1);
            chart.setPinchZoom(true);
            chart.notifyDataSetChanged();
            chart.invalidate();

            //mResult.setText(result);

            if (progressDialog != null) {
                progressDialog.dismiss();
            }
        }

        private String updateGraph() throws IOException, JSONException {

            try{
                MongoClient mongoClient = new MongoClient("10.0.0.16",27017);
                DB db = mongoClient.getDB( "test" );
                System.out.println("CONNECTED");
                DBCursor cursor = db.getCollection("tblstatus").find();
                List<DBObject> tokens = cursor.toArray();
                int weight;
                String date;
                ArrayList<Entry> entries = new ArrayList<>();
                ArrayList<String> xAxis = new ArrayList<>();

                for(int i = 0; i < tokens.size(); i++){
                    DBObject current = tokens.get(i);
                    weight = (Integer)current.get("weight");
                    date = (String)current.get("date");
                    StringUtils.substringBeforeLast(date,"/");

                    entries.add(new Entry(weight, i));
                    xAxis.add(date);
                }
                LineDataSet dataset = new LineDataSet(entries, "Weight in lbs");
                dataset.setColor(Color.rgb(0, 155, 0));
                data = new LineData(xAxis,dataset);

            }catch (UnknownHostException e){
                System.out.print("UNKNOWN HOST");
            }


            return "success";
        }
    }*/
}
