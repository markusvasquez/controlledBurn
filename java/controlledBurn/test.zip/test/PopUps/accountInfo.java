package vasudha.test.PopUps;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import org.apache.commons.lang.StringUtils;
import org.joda.time.LocalDate;

import java.lang.reflect.Array;
import java.net.URI;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

import vasudha.test.R;
import vasudha.test.Repository;
import vasudha.test.Screens.home;

/**
 * Created by Vasudha on 7/30/2016.
 */
public class accountInfo extends DialogFragment {
    public static int[] accountInfo = {0,0,0,0};
    public static Repository repo;
    OnDialogDismissListener mCallback;

    public interface OnDialogDismissListener {
        public void onDialogDismissListener(int[] account);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        final View accountDialog = inflater.inflate(R.layout.account_information, null);
        Spinner spinner = (Spinner) accountDialog.findViewById(R.id.genderField);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(accountDialog.getContext(),
                R.array.planets_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        builder.setView(accountDialog);
        builder.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {

                EditText ageText = (EditText) getDialog().findViewById(R.id.ageField);
                EditText weightText = (EditText) getDialog().findViewById(R.id.weightField);
                EditText heightText = (EditText) getDialog().findViewById(R.id.heightField);
                Spinner sexSpin = (Spinner) getDialog().findViewById(R.id.genderField);

                int age = Integer.parseInt(ageText.getText().toString());
                int weight = Integer.parseInt(weightText.getText().toString());
                int height = Integer.parseInt(heightText.getText().toString());
                int isMale;
                String sex = sexSpin.getSelectedItem().toString();
                if (sex.equals("Male")) {
                    isMale = 1;
                } else {
                    isMale = 0;

                }
                int[] account = {weight,height,age,isMale};
                OnDialogDismissListener mCallback = (OnDialogDismissListener) getTargetFragment();
                mCallback.onDialogDismissListener(account);


            }
        });

        return builder.create();
    }
   }


