package vasudha.test;


import android.content.Context;


import com.google.android.gms.tasks.RuntimeExecutionException;

import org.joda.time.LocalDate;

import java.net.URI;
import java.io.*;


public class Repository{
   final static String FIRST_DATE = "firstDate";
    final static String LAST_DATE = "lastDate";
   final static double ACCEPTABLE_WEIGHT_DEVIATION = 10;
   final static double MAX_CALORIES = 10000;
   final static double MAX_EXERCISE = 10000;
   final static int NUM_DAYS_BEFORE_START_DATE =45;//num days before start date that are queriable
   final static int DAYS_INTO_FUTURE = 7; //Number of days after current day that are queriable
  // Path path;
   URI path;
   LocalDate firstDate;
   LocalDate lastDate;



   /**  
    *Constructor for the very first day ever. Throws exception if you try to call it twice.
    *Weight in lbs, height in inches, age in years
    *@throws
    */

   public Repository(URI pathPar, LocalDate date, double weight, double height,
                     int age, boolean isMale) throws IllegalStateException {

       path = pathPar;

       //startDate is the date that the user starts using the app.
       //firstDate is the first day that we are going to consider.
       //It is NUM_DAYS_BEFORE_START_DATE before the startDate.

       firstDate = date.minusDays(NUM_DAYS_BEFORE_START_DATE);
       lastDate = date;




       //Check to see if the file with name FIRST_DATE already exists. If it does
       //throw an IllegalStateException
       if (new File(path.resolve(FIRST_DATE)).exists()) {
           throw new IllegalStateException("Repository already initialized!");
       }
       try {
           File firstFile = new File(path.resolve(FIRST_DATE));
           try {
                   PrintWriter writer = new PrintWriter(firstFile);
                   writer.println(firstDate.toString());
                   writer.close();
           } catch (IOException e) {
               System.out.println("IOEXCEPTION");
               throw new RuntimeException(e);
           }
           //Store the last date in the file whose name is LAST_DATE
           //lines = Arrays.asList(lastDate.toString());
           File lastFile = new File(path.resolve(LAST_DATE));
           try {
               //Files.write(path.resolve(LAST_DATE), lines);
                   PrintWriter writer = new PrintWriter(lastFile);
                   writer.println(lastDate.toString());
                   writer.close();
           } catch (IOException e) {
               throw new RuntimeException(e);
           }

           //Instantiate the first day and set weight to starting weight.
           Day firstDay = new Day(firstDate, weight, height, age, isMale);
           firstDay.setScaleWeight(weight);
           writeDay(firstDay);

           //Update everything from first date to lastDate (which is date).
           propagate(firstDate);




       }catch (Exception e){
            throw new RuntimeException(e);
       }
       LocalDate tempDate = new LocalDate();
       for(int i = 0; i < 7; i++){
           Day tempDay = new Day(tempDate, weight, height, age, isMale);
           tempDay.setScaleWeight(weight);
           writeDay(tempDay);
           System.out.println("STARBUCKS" + tempDate.toString() +" "+  this.getScaleWeight(tempDate));
           tempDate = tempDate.minusDays(1);
       }
   }


   /**
    *The main constructor. Likely, you will want to make a new one each time the app is pulled up.
    *The Path that it gets fed is the Path to the directory that 
    *stores the users information. The directory shouldn't change.
    */

   public Repository(URI pathPar){

      path = pathPar;
      String firstDateFromFile = "";
       String lastDateFromFile = "";
      //Read the first date from file
      try{
          System.out.println("PATH: " + (path.resolve(FIRST_DATE).toString()));
          BufferedReader reader = new BufferedReader(new FileReader(new File(path.resolve(FIRST_DATE))));
          firstDateFromFile = reader.readLine();
          reader.close();
      }catch(IOException e){
         throw new RuntimeException(e);
      }
      firstDate = LocalDate.parse(firstDateFromFile);
    
      //Read the last date from file
      try{
          BufferedReader reader = new BufferedReader(new FileReader(new File(path.resolve(LAST_DATE))));
          lastDateFromFile = reader.readLine();
          reader.close();
      } catch(IOException e){
         throw new RuntimeException(e);
      }
      lastDate = LocalDate.parse(lastDateFromFile);
       /*LocalDate temp = new LocalDate();
       for(int i=0; i < 7; i++){
           makeDate(temp);
           Day d =readDay(temp);
           System.out.println("STARBUCKS2"+d.getScaleWeight());
           temp = temp.minusDays(1);
       }*/
   }

   /**
    *set the scale weight on the given date. Weight is in lbs.
    *Throws an exception if the date is unqueriable.
    */

   public void setScaleWeight(LocalDate date, double weight) throws IllegalStateException{
      makeDate(date);
      Day day = readDay(date);
      day.setScaleWeight(weight);
      writeDay(day);
      propagate(date);
   }

   /**Set the calories on the given date. 
    *Throws an exception if the date is unqueriable.
    */
   public void setCalories(LocalDate date, double calories) throws IllegalStateException{
      
      makeDate(date);
      Day day = readDay(date);
      day.setCalories(calories);
      writeDay(day);
      propagate(date);
   }


   /**Set the exercise calories on a given date.
    *Throws an exception if the date is unqueriable.
    */
   public void setExercise(LocalDate date, double exercise) throws IllegalStateException{
   
      makeDate(date);
      Day day = readDay(date);
      day.setExercise(exercise);
      writeDay(day);
      propagate(date);
   }


   /**Get the recorded scale weight in lbs on the given date. 
    *Throws an exception if the weight was never recorded or if the date is unqueriable.
    */
   public double getScaleWeight(LocalDate date) throws IllegalStateException{
      makeDate(date);
      Day day = readDay(date);
      if(scaleWeightRecorded(date)){
          return day.getScaleWeight();
      }else{
         throw new IllegalStateException("Scale weight not recorded.");
      }
   }


   /**Gets the calories on the given date. Throws an exception if not recorded.
    *Or if the day is unqueriable.
    */
   public double getCalories(LocalDate date) throws IllegalStateException{
      makeDate(date);
      Day day = readDay(date);
      if(day.caloriesRecorded()){
         return day.getCalories();
      }else{
         return 0;
      }
      
   }


   /** Get the calories from exercise on the given date. Throws
    *an exception if the date is unqueriable.
    */
   public double getExercise(LocalDate date) throws IllegalStateException{
      makeDate(date);
      Day day = readDay(date);
      return day.getExercise();

   }

   /**Returns true if the scale weight was recorded on this date.
    *Throws an exception if the date is unqueriable.
    */
   
   public boolean scaleWeightRecorded(LocalDate date) throws IllegalStateException{
      makeDate(date);
      Day day = readDay(date);
      return day.scaleWeightRecorded();
   }

   /**Returns true if calories were recorded on that day.
    *Throws an exception if the date is unqueriable.
    */

   public boolean caloriesRecorded(LocalDate date) throws IllegalStateException{
      makeDate(date);
      Day day = readDay(date);
      return day.caloriesRecorded();
   }

   /**Returns the best weight estimate that we have for the given date.
    *Throws an exception if the date is unqueriable.
    *Does not require any information about the day to be recorded.
    *It just can't be too far in the past or future.
    */
   public double getWeightEst(LocalDate date) throws IllegalStateException{

      makeDate(date);
      Day day = readDay(date);
      return day.getWeightEst();
   }
   
   /**Returns our estimate of the non-exercise energy expenditure.
    *Throws an exception if the date is unqueriable.
    */
   public double getNEEE(LocalDate date) throws IllegalStateException{

      makeDate(date);
      Day day = readDay(date);
      return day.getNEEE();
    }



   //A method that saves a day to the file whose name is the day.getDate().toString().

   private void writeDay(Day day){

      URI newPath = path.resolve(day.getDate().toString());


      //First, delete the old file if it's there.
       if((new File(newPath)).exists()){
           new File(newPath).delete();
       }

      //Then save the new one.
      try{
          FileOutputStream fileOut = new FileOutputStream(new File(newPath));
          ObjectOutputStream outputStream = new ObjectOutputStream(fileOut);
          outputStream.writeObject(day);
          fileOut.close();
          outputStream.close();
      } catch(IOException e){
          throw new RuntimeException(e);
      }

      if(lastDate.isBefore(day.getDate())){
         lastDate = day.getDate();

         //Store the last date in the file whose name is LAST_DATE after removing that file

            //Files.deleteIfExists(path.resolve(LAST_DATE));
          if(new File(path.resolve(LAST_DATE)).exists()) {
              new File(path.resolve(LAST_DATE)).delete();
          }

         //List<String> lines = Arrays.asList(lastDate.toString());
         try{
            //Files.write(path.resolve(LAST_DATE), lines);
             PrintWriter writer = new PrintWriter(new File(path.resolve(LAST_DATE)));
             writer.println(lastDate.toString());
             writer.close();
         } catch(IOException e){
            throw new RuntimeException(e);
         }
      }
   }

   
   //A method that reads a day from its stored file.

   public Day readDay(LocalDate date){
     
      Day day = null;
       try{
             FileInputStream fileIn = new FileInputStream(new File(path.resolve(date.toString())));
             ObjectInputStream in = new ObjectInputStream(fileIn);
             day = (Day) in.readObject();
            }catch(ClassNotFoundException e){
               e.printStackTrace();
            } catch(IOException e){
               throw new RuntimeException(e);
            }
       return day;
   }

   /**Returns true if the date is queryable.
    *A date is queryable if it is not more than 7 days  in the future
    *and not more than 30 days before the first day that the user logged on to the app.
    */
   public boolean isQueryableDate(LocalDate date){
      return !(date.isBefore(firstDate) || date.isAfter(LocalDate.now().plusDays(DAYS_INTO_FUTURE)));
   }

   
   //Method that updates everything to the given date. Throws an IllegalStateException if
   //the given date is before the starting date or more than one day in the future.
   // Throws an IOException if something io goes wrong.
   private void makeDate(LocalDate date) throws IllegalStateException{

      //Throw an IllegalStateException if the queried date is before the start date.

      if(!isQueryableDate(date)){
          System.out.print(date.toString());
         IllegalStateException e = new IllegalStateException("Queried date is out of range!");
         throw e;
      }

      //if the new date is later than the previously recorded lastDate, then make it the new lastDate.
      if(lastDate.isBefore(date)){

         LocalDate tempDate = lastDate.plusDays(0);
         lastDate = date;


         //Store the last date in the file whose name is LAST_DATE after removing that file
          if(new File(path.resolve(LAST_DATE)).exists()) {
                 new File(path.resolve(LAST_DATE)).delete();
          }


         try{
             PrintWriter writer = new PrintWriter(new File(path.resolve(LAST_DATE)));
             writer.println(lastDate.toString());
             writer.close();
         }catch(IOException e){
            throw new RuntimeException(e);
         }
         //propagate changes from lastDate to date.
         propagate(tempDate);

      }


   }

   //Method that propagates changes from the date given to the lastDate.
   //Creates the intermediate dates if they don't exist, but assumes that the first date exists.
 
   private void propagate(LocalDate date){

      LocalDate tempDate = date.plusDays(0);
      Day tempDay = readDay(tempDate);

      Day tempDay2;
      Day recordedDay2;

      while(lastDate.isAfter(tempDate)){
         tempDay2 = new Day(tempDay);

        //If the day after tempDate has been recorded, then pull it from memory.
        //Copy the recorded data to tempDay2. Save tempDay2 to disk.

        if(dayExists(tempDate.plusDays(1))){
           recordedDay2 = readDay(tempDate.plusDays(1));
           
           if(recordedDay2.scaleWeightRecorded()){
              tempDay2.setScaleWeight(recordedDay2.getScaleWeight());
           }
           
           if(recordedDay2.caloriesRecorded()){
              tempDay2.setCalories(recordedDay2.getCalories());
           }

           tempDay2.setExercise(recordedDay2.getExercise());
        }

        //Now, tempDay2 is the correct follow-up day for tempDay, so write it to disk.
        writeDay(tempDay2);

        //Then increment both tempDay and tempDate.
        tempDate = tempDate.plusDays(1);
        tempDay = tempDay2; 

      }
      
   }

   //Method that indicates whether or not there is a saved Day for the corresponding date.

   public boolean dayExists(LocalDate date){
       return (new File(path.resolve(date.toString()))).exists();
   }


   /**Method that returns true if the given date is an acceptable ScaleWeight.
    *As of this writing, you can set a scale weight to be an unacceptable weight,
    *but calling this first will help to catch typos.
    */
 
   public boolean isOkayScaleWeight(LocalDate date, double weight){

      if(Math.abs(weight - getWeightEst(date)) < ACCEPTABLE_WEIGHT_DEVIATION){
         return true;
      }
      else{
         return false;
      }
   } 

   /**Method that returns true if the given date is an acceptable calories number.
    *As of this writing, you can set calories to be an unacceptable number,
    *but calling this first will help to catch typos.
    */
   public boolean isOkayCalories(LocalDate date, double calories){
      if(calories >=0 && calories < MAX_CALORIES){
         return true;
      }
      else{
         return false;
      }
   }


   /**Method that returns true if the given date is an acceptable calories number.
    *As of this writing, you can set calories to be an unacceptable number,
    *but calling this first will help to catch typos. This version doesn't require the date.
    *Both versions give the same answer.
    */ 
   public boolean isOkayCalories(double calories){
      if(calories >=0 && calories < MAX_CALORIES){
         return true;
      }
      else{
         return false;
      }
   }


   /**Method that returns true if the given date is an acceptable exercise number.
    *As of this writing, you can set exercise to be an unacceptable number,
    *but calling this first will help to catch typos.
    */
   public boolean isOkayExercise(double exercise){
   
      if(exercise >=0 && exercise < MAX_EXERCISE){
         return true;
      }
      else{
         return false;
      }
   }


   /**Method that returns true if the given date is an acceptable exercise number.
    *As of this writing, you can set exercise to be an unacceptable number,
    *but calling this first will help to catch typos. This version requires date,
    *but both will always give the same answer.
    */
   public boolean isOkayExercise(LocalDate date, double exercise){
      return isOkayExercise(exercise);
   }

   /** Returns true if the first day constructor for Repository has been called at some point
    *in time.
    */

    public static boolean repositoryInitialized(URI pathPar){
       return (new File(pathPar.resolve(FIRST_DATE)).exists());
   }

   /**
    * Returns the system to the state in which the scale weight for the given date was never set.
    */
   
   public void unsetScaleWeight(LocalDate date) throws IllegalStateException{

      makeDate(date);

      Day day = readDay(date);
      
      //Make it look like scale weight was never recorded.
      day.setScaleWeightRecorded(false);
  
      //update the posteriors on that date
      day.updatePosteriors();

      //Write that date.
      writeDay(day);

      //Propagate the changes.
      propagate(date);
 
   }


   /**
    * Returns the system to the state in which the calories for the given day was never set.
    */

   public void unsetCalories(LocalDate date) throws IllegalStateException{

      makeDate(date);

      Day day = readDay(date);
    
      //Make it look like the calories were never recorded.
      day.setCaloriesRecorded(false);
  
      //Write the day.
      writeDay(day);

      //Propagate the changes.
      propagate(date);

   }



}
