package vasudha.test;

import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import org.apache.commons.lang.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import vasudha.test.Screens.account;
import vasudha.test.Screens.diary;
import vasudha.test.Screens.home;


public class MainActivity extends AppCompatActivity implements diary.OnFragmentInteractionListener {
    private EditText caloriesEaten;
    private EditText caloriesBurned;
    private EditText weight;
    private Button send;

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);



        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.banner);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#03A9F4"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);

        home home= new home();
        getFragmentManager().beginTransaction().replace(R.id.content_id,home).commit();




        // mResult = (TextView) findViewById(R.id.tv_result);
        AHBottomNavigation bottomNavigation = (AHBottomNavigation) findViewById(R.id.bottom_navigation);
        AHBottomNavigationItem item1 = new AHBottomNavigationItem("Home", R.drawable.ic_home_black_24dp, Color.parseColor("#03A9F4"));
        AHBottomNavigationItem item2 = new AHBottomNavigationItem("Diary", R.drawable.ic_trending_up_black_24dp, Color.parseColor("#03A9F4"));
        AHBottomNavigationItem item3 = new AHBottomNavigationItem("Account", R.drawable.ic_account_box_black_24dp, Color.parseColor("#03A9F4"));




        bottomNavigation.addItem(item1);
        bottomNavigation.addItem(item2);
        bottomNavigation.addItem(item3);
        bottomNavigation.setDefaultBackgroundColor(Color.parseColor("#FEFEFE"));
        bottomNavigation.setAccentColor(Color.parseColor("#F63D2B"));
        bottomNavigation.setInactiveColor(Color.parseColor("#747474"));

        //  Enables Reveal effect
        bottomNavigation.setColored(true);
        bottomNavigation.setCurrentItem(0);

        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public void onTabSelected(int position, boolean wasSelected) {
                if(position == 0 ){
                    home home = new home();
                    getFragmentManager().beginTransaction().replace(R.id.content_id,home).commit();

                }
                else if(position == 1 ){
                    diary diary = new diary();
                    getSupportFragmentManager().beginTransaction().replace(R.id.content_id,diary).commit();

                }
                else{
                    account account = new account();
                    getSupportFragmentManager().beginTransaction().replace(R.id.content_id,account).commit();

                }
            }
        });




       /* send = (Button) findViewById(R.id.Send);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                caloriesEaten = (EditText) findViewById(R.id.caloriesEatenField);
                caloriesBurned = (EditText) findViewById(R.id.caloriesBurnedField);
                weight = (EditText) findViewById(R.id.weightField);


                int caloriesEatenInput = Integer.parseInt(caloriesEaten.getText().toString());
                int caloriesBurnedInput = Integer.parseInt(caloriesBurned.getText().toString());
                int weightInput = Integer.parseInt(weight.getText().toString());

                String url = "http://10.0.0.16:3000/api/status/";

                Day d = new Day(url,caloriesEatenInput,caloriesBurnedInput,weightInput);

                new PostDataTask().execute(d);
                new GetDataTask().execute(url);
            }
        });

        //Day d = new Day("http://10.0.0.16:3000/api/status/",400,400,222);

        //new PostDataTask().execute(d);
    //make a GET REQUEST
      // new GetDataTask().execute("http://10.0.0.16:3000/api/status/");
        //Day d = new Day("http://10.0.0.16:3000/api/status/",1000,2000,134);

        //new PostDataTask().execute(d);
        //new PutDataTask().execute("http://10.0.0.16:3000/api/status/574f738d47f423483638f36c");
    //new DeleteDataTask().execute("http://10.0.0.16:3000/api/status/574f73a347f423483638f36d");*/
    }

    @Override
    public void onDiaryInteraction(){
        //diary d = new diary();
        TextView tv = (TextView)findViewById(R.id.weightText);
        tv.setText("LOL");

    }

/*

    class GetDataTask extends AsyncTask<String,Void,String>{

        private ArrayList<Day> dayify(String[] tokens){

            ArrayList<Day> result = new ArrayList<>();
            int j;
            Day dayToAdd;
            String caloriesEaten;
            String caloriesBurned;
            String weight;
            for(j = 0; j < tokens.length; j++ ){

                caloriesEaten = StringUtils.substringBetween(tokens[j],"\"caloriesEaten\":",",");
                caloriesBurned = StringUtils.substringBetween(tokens[j],"\"caloriesBurned\":",",");
                weight = StringUtils.substringBetween(tokens[j],"\"weight\":",",");

                System.out.println(tokens[j]);
                System.out.println(caloriesEaten + " " +  caloriesBurned + " " + weight);

           //     dayToAdd = new Day(Integer.parseInt(caloriesEaten),Integer.parseInt(caloriesBurned),Integer.parseInt(weight));
             //   result.add(dayToAdd);
            }
            return result;
        }

        private void populateListView(String[] tokens){


            ArrayList<Day> list = dayify(tokens);
            DayAdapter adapter = new DayAdapter(MainActivity.this,list);

            ListView listview = (ListView) findViewById(R.id.listView);
            listview.setAdapter(adapter);
        }

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute(){
            super.onPreExecute();
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Loading Data...");
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            try{
                return getData(params[0]);
            }
            catch (IOException e){
                    return "Network error!";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            //System.out.print("RESULT: " +result);
            String[] tokens = result.split("\\},");

          */
/*  int j;
            for( j = 0; j <tokens.length; j++ ){
                    System.out.println(tokens[j]);
            }
*//*

            populateListView(tokens);


            //set data response to TextView
           // mResult.setText(result);

            //cancel progress dialog
            if(progressDialog != null)
            {
                progressDialog.dismiss();
            }
        }
        private String getData(String urlPath) throws IOException{
            StringBuilder result = new StringBuilder();
            BufferedReader bufferedReader = null;
            try{
                //initialize configure and connect
                URL url = new URL(urlPath);
                HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
                urlConnection.setReadTimeout(1000);
                urlConnection.setConnectTimeout(1000);
                urlConnection.setRequestMethod("GET");
                urlConnection.setRequestProperty("Content-Type","application/json");
                urlConnection.connect();


                //read data from server
                InputStream inputStream = urlConnection.getInputStream();
                bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String line;
                while((line = bufferedReader.readLine()) != null)
                {
                    result.append(line);
                }


            }finally {
                if(bufferedReader != null ){
                    bufferedReader.close();
                }
            }
            return result.toString();
        }
    }
    class PostDataTask extends AsyncTask<Day, Void, String> {

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Inserting data...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Day... params) {

            try {
                return postData(params[0].getUrl(),params[0].getCaloriesEaten(),params[0].getCaloriesBurned(),params[0].getWeight());
            } catch (IOException ex) {
                return "Network error !";
            } catch (JSONException ex) {
                return "Data Invalid !";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            //mResult.setText(result);

            if (progressDialog != null) {
                progressDialog.dismiss();
            }
        }

        private String postData(String urlPath,int caloriesEaten, int caloriesBurned,int weight) throws IOException, JSONException {

            StringBuilder result = new StringBuilder();
            BufferedWriter bufferedWriter = null;
            BufferedReader bufferedReader = null;

            try {
                //Create data to send to server
                JSONObject dataToSend = new JSONObject();
                dataToSend.put("caloriesEaten", caloriesEaten);
                dataToSend.put("caloriesBurned", caloriesBurned);
                dataToSend.put("weight", weight);


                //Initialize and config request, then connect to server.
                URL url = new URL(urlPath);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setReadTimeout(10000 */
/* milliseconds *//*
);
                urlConnection.setConnectTimeout(10000 */
/* milliseconds *//*
);
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);  //enable output (body data)
                urlConnection.setRequestProperty("Content-Type", "application/json");// set header
                urlConnection.connect();

                //Write data into server
                OutputStream outputStream = urlConnection.getOutputStream();
                bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream));
                bufferedWriter.write(dataToSend.toString());
                bufferedWriter.flush();

                //Read data response from server
                InputStream inputStream = urlConnection.getInputStream();
                bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    result.append(line).append("\n");
                }
            } finally {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (bufferedWriter != null) {
                    bufferedWriter.close();
                }
            }

            return result.toString();
        }
    }
    class PutDataTask extends AsyncTask<String,Void,String>{
        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute(){
            super.onPreExecute();
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Updating...");
            progressDialog.show();
        }
        @Override
        protected String doInBackground(String...params){
            try{
                return putData(params[0]);

            }catch (IOException e){
                return "Network Error!";

            }catch(JSONException e){
                return "JSON EXCEPTION!";
            }
        }
        @Override
        protected void onPostExecute(String result){
                super.onPostExecute(result);
            if(progressDialog != null){
                progressDialog.dismiss();
            }

        }
        private String putData(String urlPath) throws IOException, JSONException{
            BufferedWriter bufferedWriter = null;
            String result = null;
            try {
                JSONObject dataToSend = new JSONObject();
                dataToSend.put("fbname", "Vasudha Kashyap");
                dataToSend.put("content", "feeling updated");
                dataToSend.put("likes", 2);
                dataToSend.put("comments", 2);

                //initiali
                URL url = new URL(urlPath);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setReadTimeout(1000);
                urlConnection.setConnectTimeout(1000);
                urlConnection.setRequestMethod("PUT");
                urlConnection.setDoOutput(true);
                urlConnection.setRequestProperty("Content-Type", "application/json");
                urlConnection.connect();

                OutputStream outputStream = urlConnection.getOutputStream();
                bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream));
                bufferedWriter.write(dataToSend.toString());
                bufferedWriter.flush();

                //check if success
                if (urlConnection.getResponseCode() == 200) {
                    return "Update Successfully!";
                } else {
                    return "Update Failed";
                }

            }finally{
                    if(bufferedWriter != null){
                            bufferedWriter.close();
                    }
            }
        }

    }
    class DeleteDataTask extends AsyncTask<String,Void,String>{

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute(){
            super.onPreExecute();
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Deleting...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String...params){
                try{
                    return deleteData(params[0]);
                }catch(IOException e){
                    return "Network Error";
                }

            }
        @Override
        protected void onPostExecute(String result){
            super.onPostExecute(result);
            if(progressDialog != null){
                    progressDialog.dismiss();
            }
        }
        private String deleteData(String urlPath) throws IOException{
            String result = null;
            //initialize
            URL url = new URL(urlPath);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setReadTimeout(1000);
            urlConnection.setConnectTimeout(1000);
            urlConnection.setRequestMethod("DELETE");
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.connect();

            //check update successful or not
            if(urlConnection.getResponseCode() == 204){
                result = "Delete Successful";
            }
            else{
                result = "Delete Failed";
            }

            return result;
        }
    }
*/


}

